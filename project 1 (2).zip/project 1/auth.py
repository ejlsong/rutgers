import argparse
import pickle
import sys
import json
from os import path
from json.decoder import JSONDecodeError

permissions = {"auth", "view", "delete"}

# ------------------------------------------------------------------------------------ #
# ----------------------------------------Main---------------------------------------- #
# ------------------------------------------------------------------------------------ #

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('permission')

    sparser = parser.add_subparsers(dest='command')

    adduser = sparser.add_parser('AddUser')
    adduser.add_argument('commands', type=str, nargs='*')

    auth = sparser.add_parser('Authenticate')
    auth.add_argument('commands', type=str, nargs='*')

    setdomain = sparser.add_parser('SetDomain')
    setdomain.add_argument('commands', type=str, nargs='*')

    domaininfo = sparser.add_parser('DomainInfo')
    domaininfo.add_argument('commands', type=str, nargs='*')

    settype = sparser.add_parser('SetType')
    settype.add_argument('commands', type=str, nargs='*')

    typeinfo = sparser.add_parser('TypeInfo')
    typeinfo.add_argument('commands', type=str, nargs='*')

    addaccess = sparser.add_parser('AddAccess')
    addaccess.add_argument('commands', type=str, nargs='*')

    canaccess = sparser.add_parser('CanAccess')
    canaccess.add_argument('commands', type=str, nargs='*')

    args = parser.parse_args()

    if args.permission not in permissions:
        print("Error: invalid permission")
        return

    # add user
    if args.command == "AddUser":
        if len(args.commands) == 2:
            addUser(args.commands[0],args.commands[1])
        else:
            if len(args.commands) < 2:
                print("Error: too few arguments for AddUser")
            if len(args.commands) > 2:
                print("Error: too many arguments for AddUser")

    # authenticate
    elif args.command == "Authenticate":
        if len(args.commands) == 2:
            authenticate(args.commands[0],args.commands[1])
        else:
            if len(args.commands) < 2:
                print("Error: too few arguments for Authenticate")
            if len(args.commands) > 2:
                print("Error: too many arguments for Authenticate")


    # set domain
    elif args.command == "SetDomain":
        if len(args.commands) == 2:
            setDomain(args.commands[0],args.commands[1])
        else:
            if len(args.commands) < 2:
                print("Error: too few arguments for SetDomain")
            if len(args.commands) > 2:
                print("Error: too many arguments for SetDomain")


    # domain info
    elif args.command == "DomainInfo":
        if len(args.commands) == 1:
            domainInfo(args.commands[0])
        else:
            if len(args.commands) < 1:
                print("Error: too few arguments for DomainInfo")
            if len(args.commands) > 1:
                print("Error: too many arguments for DomainInfo")

    # set type
    elif args.command == "SetType":
        if len(args.commands) == 2:
            setType(args.commands[0],args.commands[1])
        else:
            if len(args.commands) < 2:
                print("Error: too few arguments for SetType")
            if len(args.commands) > 2:
                print("Error: too many arguments for SetType")

    # type info
    elif args.command == "TypeInfo":
        if len(args.commands) == 1:
            typeInfo(args.commands[0])
        else:
            if len(args.commands) < 1:
                print("Error: too few arguments for TypeInfo")
            if len(args.commands) > 1:
                print("Error: too many arguments for TypeInfo")

    # add access
    elif args.command == "AddAccess":
        if len(args.commands) == 3:
            addAccess(args.commands[0],args.commands[1],args.commands[2])
        else:
            if len(args.commands) < 3:
                print("Error: too few arguments for AddAccess")
            if len(args.commands) > 3:
                print("Error: too many arguments for AddAccess")

    # can access
    elif args.command == "CanAccess":
        if len(args.commands) == 3:
            canAccess(args.commands[0],args.commands[1],args.commands[2])
        else:
            if len(args.commands) < 3:
                print("Error: too few arguments for CanAccess")
            if len(args.commands) > 3:
                print("Error: too many arguments for CanAccess")
    else:
        print("Error: invalid command {}".format(args.command))






# ------------------------------------------------------------------------------------ #
# ---------------------------------Required Functions--------------------------------- #
# ------------------------------------------------------------------------------------ #


def addUser(user, passw):  # add user:password to user dictionary
    if user == "":
        print("Error: username missing")
        return

    if not path.exists("users.json"):
        open("users.json", "w+")

    f = open("users.json", "r")
    try:
        users = json.load(f)

        if user in users:
            print("Error: user exists")

        else:
            users[user] = {"username": user, "password": passw, "domains": []}

            f = open("users.json", "w+")
            json.dump(users, f, indent=4)
            print("Success")

    except JSONDecodeError:
        f = open("users.json", "w+")

        users = {user: {"username": user, "password": passw, "domains": []}}

        json.dump(users, f, indent=4)
        print("Success")


def authenticate(user, passw):
    if not path.exists("users.json"):
        print("Error: no such user")
        return

    f = open("users.json", "r")

    try:
        users = json.load(f)

        if user in users:
            if users[user]["password"] != passw:
                print("Error: bad password")
                return
        else:
            print("Error: no such user")
            return
    except JSONDecodeError:
        print("Error: no such user")
        return

    print("Success")


def setDomain(user, domain):  # assign a user to a domain, check if works later
    if domain == "":
        print("Error: missing domain")
        return

    # check if user exists
    if not path.exists("users.json"):
        print("Error: no such user")  # users.json file does not exist yet
        return

    else:
        f = open("users.json", "r")
        try:
            users = json.load(f)

            if user not in users:
                print("Error: no such user")  # users.json exists but user is not in in
                return

        except:
            print("Error: no such user")  # users.json is empty
            return

    if not path.exists("domains.json"):
        open("domains.json", "w+")

    f = open("domains.json", "r")

    try:
        domains = json.load(f)

        f = open("domains.json", "w+")

        if domain not in domains:
            domains[domain] = {"domain name": domain, "users": [user]}
        else:
            if user not in domains[domain]["users"]:
                domains[domain]["users"].append(user)

        json.dump(domains, f, indent=4)

    except:
        domains = {"domain name": {"domain name" : domain, "users" : [user]}}
        f = open("domains.json","w+")
        json.dump(domains, f, indent=4)


def domainInfo(domain):
    if domain == "":
        print("Error: missing domain")
        return

    if not path.exists("domains.json"):
        open("domains.json", "w+")


    f = open("domains.json", "r")

    try:
        domains = json.load(f)
        if domain in domains:
            for user in domains[domain]["users"]:
                print(user)
        else:
            
            return

    except JSONDecodeError:
       
        return



def setType(objname, type):
    if objname == "":
        print("Error: object name missing")
        return
    if type == "":
        print("Error: type name missing")
        return

    if not path.exists("types.json"):
        open("types.json", "w+")

    f = open("types.json", "r")

    try:
        types = json.load(f)
        if type in types:
            if objname not in types[type]["objects"]:
                types[type]["objects"].append(objname)
            else:
                print("{} is already a {}.".format(objname, type))
                return
        else:
            types[type] = {"name" : type, "objects" : objname}

    except JSONDecodeError:
        types = {type : {"name" : type, "objects" : [objname]}}

    f = open("types.json", "w+")

    json.dump(types, f, indent=4)

    print("Success")



def typeInfo(type):
    if type == "":
        print("Error: type name missing")
        return

    if not path.exists("types.json"):
        open("types.json", "w+")
        

    f = open("types.json","r")

    try:
        types = json.load(f)

        if type in types:
            for obj in types[type]["objects"]:
                print(obj)
        else:
           
            return

    except JSONDecodeError:
        
        return




def addAccess(op, domain, type):   #update matrix
    if op == "":
        print("Error: missing operation")
        return
    if domain == "":
        print("Error: missing domain")
        return
    if type == "":
        print("Error: missing type")
        return

    #check domain
    domain_ex = False

    if not path.exists("domains.json"):
        domain_ex = False

    f = open('domains.json')

    try:
        domains = json.load(f)
        if domain in domains:
            domain_ex = True
    except JSONDecodeError:
        domain_ex = False

    if domain_ex == False:
        if not path.exists("domains.json"):
            open("domains.json", "w+")

        f = open("domains.json", "r")
        try:
            domains = json.load(f)

            domains[domain] = {"domain name" : domain, "users" : []}

        except JSONDecodeError:
            domains = {domain: {"domain name": domain, "users": []}}


        f = open("domains.json", "w+")
        json.dump(domains, f, indent=4)

    #check type
    type_ex = False

    if not path.exists("types.json"):
        type_ex = False

    f = open('types.json')

    try:
        types = json.load(f)
        if type in types:
            type_ex = True
    except JSONDecodeError:
        type_ex = False

    if type_ex == False:
        if not path.exists("types.json"):
            open("types.json", "w+")

        f = open("types.json", "r")
        try:
            types = json.load(f)

            types[domain] = {"type name": type, "objects": []}

        except JSONDecodeError:
            types = {type: {"type name": domain, "objects": []}}

        f = open("types.json", "w+")
        json.dump(types, f, indent=4)

    #check permission
    if not path.exists("permissions.json"):
        open("permissions.json", "w+")

    f = open("permissions.json","r")

    try:
        permissions = json.load(f)

        if op not in permissions:
            permissions[op] = {"name" : op, "domains" : {domain : [type]}}
        else:
            if domain in permissions[op]["domains"]:
                if type not in permissions[op]["domains"][domain]:
                    permissions[op]["domains"][domain].append(type)

            else:
                permissions[op]["domains"][domain] = [type]

    except JSONDecodeError:
        permissions = {op: {"name": op, "domains": {domain: [type]}}}

    f = open("permissions.json", "w+")

    json.dump(permissions, f, indent=4)


def canAccess(op, user, obj):
    if op == "" or user == "" or obj == "":
        print("Error: access denied")
        return


    type_ex = False

    if not path.exists("types.json"):
        type_ex = False

    f = open('types.json')

    try:
        types = json.load(f)
        if type in types:
            type_ex = True
    except JSONDecodeError:
        type_ex = False



    user_ex = False

    if not path.exists("users.json"):
        user_ex = False

    f = open("users.json", "r")
    try:
        users = json.load(f)

        if user in users:
            user_ex = True

    except JSONDecodeError:
        user_ex = False

    if user_ex == False:
        print("Error: access denied")
        return



    if not path.exists("users.json"):
        open("users.json", "w+")
        print("Error: access denied")
        return

    f = open("users.json", "r")

    try:
        users = json.load(f)

        userdomain = users[user]["domains"]

    except JSONDecodeError:
        print("Error: access denied")
        return

    if not path.exists("permissions.json"):
        open("permissions.json", "w+")
        print("Error: access denied")
        return

    perm_ex = False
    f = open("permissions.json", "r")

    try:
        types = json.load(f)
        if op in types:
            perm_ex = True
    except JSONDecodeError:
        perm_ex = False
    if perm_ex == False:
        print("Error: access denied")
        return

    f = open("permissions.json", "r")
    try:
        perms = json.load(f)
        permdomains = perms[op]["domains"]

    except JSONDecodeError:

        print("Error: access denied")
        return

    shareddomains = []

    for ud in userdomain:
        if ud in permdomains:
            shareddomains.append(ud)

    sharedtypes = []
    for sd in shareddomains:
        for ttype in permdomains[sd]:
            if ttype not in sharedtypes and type_ex == True:
                sharedtypes.append(ttype)


    if not path.exists("types.json"):
        open("types.json", "w+")
        print("Error: access denied")
        return

    f = open("types.json", "r")
    try:
        types = json.load(f)
    except JSONDecodeError:
        print("Error: access denied")
        return

    for ttype in sharedtypes:
        if obj in types[ttype]["objects"]:
            print("Success")
            return

    print("Error: access denied")


# ------------------------------------------------------------------------------------ #
# --------------------------------------Run Main-------------------------------------- #
# ------------------------------------------------------------------------------------ #


if __name__ == "__main__":
    main()



