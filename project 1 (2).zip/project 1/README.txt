1. Run the Python file in the command prompt as usual. ex. python3 auth.py auth AddUser user pass

2. No setup is needed. Everything will be stored in JSON files in the same directory as the program. Just make sure you are running on Python3.

3. Too few arguments and too many arguments are invalid. Any permission besides auth, view, or delete are invalid. 
Any commands besides the ones specified in the project description are invalid. Lowercase letters are invalid.

AddUser: AddUser user pass -> success
         AddUser user pass -> error: user already exists
         AddUser user2 pass2 -> success

Authenticate: Authenticate user pass -> success
              Authenticate user pas -> error: bad password

SetDomain: SetDomain user domain1 -> success
           SetDomain user domain1 -> error: user already in domain
           SetDomain nouser domain1 -> error: user does not exist
           SetDomain user "" -> error: missing domain
           SetDomain user2 domain2 -> success

DomainInfo: DomainInfo domain1 -> user, user2
            DomainInfo "" -> error: missing domain
            DomainInfo domain3-> 


SetType: SetType obj1 type1 -> success 
         SetType "" type1 -> error: missing object
         SetType obj1 "" -> error: missing type

TypeInfo: TypeInfo type1 -> obj1
          TypeInfo asdfofawfwfw ->
          TypeInfo "" -> error: missing type

AddAccess: AddAccess w domain1 type -> success
           AddAccess "" domain1 type -> error: missing permission
           AddAccess w "" type -> error: missing domain
           AddAccess w domain1 "" -> error: missing type

CanAccess: CanAccess w user obj1 -> success
           CanAccess w user2 obj1 -> error: access denied
           CanAccess "" user obj1 -> error: missing permission
           CanAccess w "" obj1 -> error: missing user
           CanAccess w user "" -> error: missing object
