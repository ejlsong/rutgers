#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <dlfcn.h>
#include <string.h>




// Name: Eric Song
// netID: ejs244
// RUID: 185003641
// your code for readdir goes here

struct dirent* readdir(DIR *dirp){
    

    char* env = getenv("HIDDEN");


    struct dirent* (*readdir2) (DIR* dirp);
    readdir2 = dlsym(RTLD_NEXT, "readdir");

    struct dirent* d = readdir2(dirp);

    while( d != NULL){
        if (strstr(d->d_name, env) == 0){
            break;
        }
        d = readdir2(dirp);
        
    }
    return d;
}



