#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <dlfcn.h>
#include <string.h>
#include <time.h>

// Name: Eric Song
// netID: ejs244
// RUID:185003641
// your code for time() goes here
int check = 0;

time_t time(time_t *tloc){

    if (check == 0){   //the first time the program is run

        struct tm tm;   

        strptime("1/2/2021 3:30:00", " %m/%d/%Y %H:%M:%S", &tm);   //insert time into tm structure


        if (tloc == NULL){   //allocate memory
            tloc = (time_t *)malloc(sizeof(time_t));
        }


        *tloc = mktime(&tm);   //put altered time in

        check = 1;   //subsequent calls of time will call correctly
        return *tloc;
    }

    time_t (*time2)(time_t * tloc);   //time calls normally
    time2 = dlsym(RTLD_NEXT, "time");

    return time2(tloc);
}
