import argparse
from os import path
import sys


#(i+j) mod 256

def main():

    #parse all file names
    parser = argparse.ArgumentParser()


    
    parser.add_argument("keyfile")
    parser.add_argument("ciphertext")
    parser.add_argument("plaintext")

    args = parser.parse_args()

    if not len(vars(args)) == 3:
        print("Not enough arguments.")
        return

    kf = open(args.keyfile, "rb")
    ptf = open(args.plaintext, "wb")
    ctf = open(args.ciphertext, "rb")

    while True:
        cipher_char = ctf.read(1)
        if not cipher_char:
            break
        
        if kf:
            key_char = kf.read(1)
            if not key_char:
                kf.seek(0)
                key_char = kf.read(1)

        else:
            key_char = 0

        byte_cchar = int.from_bytes(cipher_char,byteorder=sys.byteorder)
        byte_kchar = int.from_bytes(key_char,byteorder=sys.byteorder)

        
        ptf.write(int.to_bytes((byte_cchar - byte_kchar)%256,byteorder=sys.byteorder,length=1))

    
    kf.close()
    ptf.close()
    ctf.close()

if __name__ == '__main__':
    main()

