import argparse
from os import path
import sys

#!/usr/bin/python3

#(i+j) mod 256

def main():

    #parse all file names
    parser = argparse.ArgumentParser()


    
    parser.add_argument("keyfile")
    parser.add_argument("plaintext")
    parser.add_argument("ciphertext")

    args = parser.parse_args()

    if not len(vars(args)) == 3:
        print("Not enough arguments.")
        return

    kf = open(args.keyfile, "rb")
    ptf = open(args.plaintext, "rb")
    ctf = open(args.ciphertext, "wb")

    while True:
        plain_char = ptf.read(1)
        if not plain_char:
            break
        
        if kf:
            key_char = kf.read(1)
            if not key_char:
                kf.seek(0)
                key_char = kf.read(1)
        else:
            key_char = 0


        byte_pchar = int.from_bytes(plain_char,byteorder=sys.byteorder)
        byte_kchar = int.from_bytes(key_char,byteorder=sys.byteorder)

        
        ctf.write(int.to_bytes((byte_pchar+byte_kchar)%256,byteorder=sys.byteorder,length=1))


if __name__ == '__main__':
    main()

