import argparse
from os import path
import sys


#(i+j) mod 256

def main():

    #parse all file names
    parser = argparse.ArgumentParser()


    
    parser.add_argument("keyfile")
    parser.add_argument("plaintext")
    parser.add_argument("ciphertext")

    args = parser.parse_args()

    if not len(vars(args)) == 3:
        print("Not enough arguments.")
        return

    kf = open(args.keyfile, "rb")
    ptf = open(args.plaintext, "rb")
    ctf = open(args.ciphertext, "wb")

    

if __name__ == '__main__':
    main()

