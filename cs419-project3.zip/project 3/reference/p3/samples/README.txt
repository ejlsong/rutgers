Sample documents for testing encryption

alice.txt	149314 bytes of Alice in Wonderland
clown.jpg	JPEG image of a clown
poem.txt	3277-byte poem
test-15.txt	15-byte file with the text "This is the end"
test-16.txt	16-byte file with the text "This is the end\n"
test-41.txt	41-byte text to take up more than 1 block for Part 3
test-a.txt	One byte (the letter "A")
test-abc.txt	Three bytes (the text "ABC")
test-null.txt	Empty file - zero bytes
