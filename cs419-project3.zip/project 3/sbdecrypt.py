import argparse
from os import path
import os


blocksize = 16

def getSize(filename):
    st = os.stat(filename)
    return st.st_size


def sbdm(str):
    max = 18446744073709551615 + 1
    hash = 0
 
    for char in str:
        hash = ord(char) + (hash << 6) + (hash << 16) - hash

    return hash % max


def lcg(x):
    return (1103515245*x + 12345)%256  


def getiv(seed):
    iv = []
    x = lcg(seed)
    iv.append(x)
    
    for i in range(blocksize-1):
        x = lcg(x)
        iv.append(x)

    return iv


def pad(string):
    last = string[-1]

    if not(last >= 0 and last <= blocksize ):
        return string
    
    result = []
    for i in range(blocksize -1,-1,-1):
        if (not string[i] == last) or (i < blocksize-last):
            result.insert(0, string[i])

    return bytes(result)

    
def shuffle(x, stream):

    x = list(x)

    for i in range(blocksize -1, -1, -1):
        first = stream[i] & (blocksize-1)
        second = (stream[i] >> 4) & (blocksize-1)

        temp = x[first]
        x[first] = x[second]
        x[second] = temp

    return bytes(x)


def xor(plain, text):
    result = []
    for i in range(len(plain)):
        result.append(plain[i] ^ text[i])
    
    return bytes(result)



def main():
    parser = argparse.ArgumentParser()


    parser.add_argument("password")
    parser.add_argument("ciphertext")
    parser.add_argument("plaintext")

    args = parser.parse_args()

    if not len(vars(args)) == 3:
        print("Not enough arguments.")
        return

    password = args.password
    ctf = open(args.ciphertext, 'rb')
    ptf = open(args.plaintext, 'wb+')

    seed = sbdm(password)

    iv = getiv(seed)

    x = 1
    f = 1
    ciphertext = []

    total = getSize(args.ciphertext)
    read = 0
    prev = None
    

    while x == 1:

        string = ctf.read(blocksize)

        read+= len(string)

        if f:
            stream = getiv(iv[-1])
            n = xor(string, stream)
        else:
            stream = getiv(stream[-1])
            n = xor(string, stream)

        

        swapped = shuffle(n, stream)

        if f == 1:
            f = 0
            ciphertext = xor(swapped, iv)
        else:
            ciphertext = xor(swapped, prev)

        if read == total:
            ciphertext = pad(ciphertext)
            x = 0

        prev = string

        ptf.write(ciphertext)

        

    ctf.close()
    ptf.close()


if __name__ == "__main__":
    main()