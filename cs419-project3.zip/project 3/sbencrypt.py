import argparse
from os import path


blocksize = 16


def sbdm(str):
    max = 18446744073709551615 + 1
    hash = 0

    for char in str:
        hash = ord(char) + (hash << 6) + (hash << 16) - hash

    return hash % max


def lcg(x):
    return (1103515245*x + 12345)%256  


def getiv(seed):
    iv = []
    x = lcg(seed)
    iv.append(x)
    
    for i in range(blocksize-1):
        x = lcg(x)
        iv.append(x)

    return iv


def pad(string):
    length = len(string)

    if (length == 0):
        list = []
        for i in range(blocksize):
            list.append(blocksize)

        return bytes(list)
    
    list = []
    for i in string:
        list.append(i)

    for index in range(blocksize - length):
        list.append(blocksize-length)
    
    return bytes(list)
    
def shuffle(x, stream):

    x = list(x)

    for i in range(blocksize):
        first = stream[i] & (blocksize-1)
        second = (stream[i] >> 4) & (blocksize-1)

        temp = x[first]
        x[first] = x[second]
        x[second] = temp

    return bytes(x)


def xor(plain, text):
    result = []
    for i in range(len(plain)):
        result.append(plain[i] ^ text[i])
    
    return bytes(result)



def main():
    parser = argparse.ArgumentParser()


    parser.add_argument("password")
    parser.add_argument("plaintext")
    parser.add_argument("ciphertext")

    args = parser.parse_args()

    if not len(vars(args)) == 3:
        print("Not enough arguments.")
        return

    password = args.password
    ptf = open(args.plaintext, 'rb')
    ctf = open(args.ciphertext, 'wb+')

    seed = sbdm(password)

    iv = getiv(seed)

    x = 1
    f = 1
    ciphertext = []

    while x == 1:

        string = ptf.read(blocksize)

        if not len(string) == blocksize:
            string = pad(string)
            x = 0

        if f == 1:
            f = 0

            list  = xor(string, iv)
            stream = getiv(iv[-1]) 

        swapped = shuffle(list, stream)

        ciphertext = xor(swapped, stream)

        ctf.write(ciphertext)

    ctf.close()
    ptf.close()


if __name__ == "__main__":
    main()