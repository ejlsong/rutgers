Please ignore vtest.py.

Additionally, p3.zip and reference are the reference programs provided.