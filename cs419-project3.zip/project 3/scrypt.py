import argparse
from os import path
import sys

def sbdm(str):
    max = 18446744073709551615 + 1
    hash = 0
    c = 0
    for char in str:
        hash = ord(char) + (hash << 6) + (hash << 16) - hash



    return hash % max


def lcg(x):
    return (1103515245*x + 12345)%256



def main():
    parser = argparse.ArgumentParser()


    parser.add_argument("password")
    parser.add_argument("plaintext")
    parser.add_argument("ciphertext")

    args = parser.parse_args()

    if not len(vars(args)) == 3:
        print("Not enough arguments.")
        return

    password = args.password
    ptf = open(args.plaintext, 'rb')
    ctf = open(args.ciphertext, 'wb+')

    seed = sbdm(password)
    key = lcg(seed)

    #print(seed)

    while True:
        c = ptf.read(1)
        if not c:
            break

        xor = int.from_bytes(c, byteorder=sys.byteorder) ^ key
        ctf.write(int.to_bytes(xor,byteorder=sys.byteorder,length=1))

        key = lcg(key)
    
    ptf.close()
    ctf.close

if __name__ == "__main__":
    main()


        