#!/usr/bin/python3 

import hashlib
import time
import argparse

zeroes = { '0': 4, '1': 3, '2':2, '3':2, '4':1, '5':1, '6':1, '7':1, '8':0, '9':0, 'a':0, 'b':0, 'c':0, 'd':0, 'e':0,'f':0 }

def update_hash(str):
    m = hashlib.sha256()

    m.update(str)

    return m.hexdigest()

def get_leading(hash):
    leading = 0

    for c in hash:
        if c != '0':
            break
        else:
            leading+=4

    return leading + zeroes[c.lower()]

def main():
   
    valid = True
    parser = argparse.ArgumentParser()

    parser.add_argument("powheader")
    parser.add_argument("file")

    args = parser.parse_args()

    if not len(vars(args)) == 2:
        print("Error. Not enough arguments.")
        return

    if args.powheader == "":
        print("Error. Missing header.")
        return

    if args.file == "":
        print("Error. Missing file.")
        return

    header  = open(args.powheader, "r")
    text = open(args.file, "rb")

    message  = text.read()
    hash1 = update_hash(message)


    ih_valid = True
    pow_valid = True
    hash_valid = True
    leading_valid = True



    for line in header:
        if "INITIAL-HASH: " in line.upper():
            
            hash2 = line[line.find(":")+2].strip()

        elif "PROOF-OF-WORK: " in line.upper():
            pow = line[line.find(":")+2].strip()
            

        elif "HASH: " in line.upper():
            hash_final = line[line.find(":")+2].strip()
            

        elif "LEADING-BITS" in line.upper():
            leading = line[line.find(":") + 2].strip()
            

    if not hash2:
        print("ERROR: missing Initial-hash in header")
        ih_valid = False
    
    if not pow:
        print("ERROR: missing Proof-of-work in header")
        pow_valid  = False

    if not hash_final:
        print("ERROR: missing Hash in header")
        hash_valid = False
        

    if not leading:
        print("ERROR: missing Leading-bits in header")
        leading_valid = False
        


    
    if hash1 != hash2 and ih_valid == True:
        print("ERROR: initial hashes don't match")
        print("hash in header: {}".format(hash2))
        print("file hash: {}".format(hash1))
        valid = False   
    elif hash1 == hash2 and ih_valid == True:
        print("PASSED: initial file hashes match")

    
    leading_final = get_leading(hash_final)

    leading = int(leading)

    if leading != leading_final and leading_valid == True:
        print("ERROR: incorrect Leading-bits value: {}, expected {}".format(leading, leading_final))
        valid = False
    elif leading == leading_final and leading_valid == True:
        print("PASSED: leading bits is correct")
    

    message_final = pow + hash2
    hash_final2 = update_hash(str.encode(message_final))

    if hash_final != hash_final2 and hash_valid == True:
        print("ERROR: pow hash does not match Hash header")
        print("expected: {}".format(hash_final))
        print("header has: {}".format(hash_final2))
        valid = False
    elif hash_final == hash_final2 and hash_valid == True:
        print("pow hash matches Hash header")
    


    if valid == False or ih_valid == False or pow_valid == False or leading_valid == False or hash_valid == False:
        print("fail")
        return

    print("pass")

    header.close()
    text.close()

if __name__ == "__main__":
    main()


