#!/usr/bin/python3 

import hashlib
import time
import argparse

zeroes = { '0': 4, '1': 3, '2':2, '3':2, '4':1, '5':1, '6':1, '7':1, '8':0, '9':0, 'a':0, 'b':0, 'c':0, 'd':0, 'e':0,'f':0 }

def update_hash(str):
    m = hashlib.sha256()

    m.update(str)

    return m.hexdigest()

def check_leading(n, hash):

    leading = n // 4
    if hash[:leading] != ''.join(['0' for _ in range(leading)]):
        return False
    
    remaining_zero = n % 4
    

    if zeroes[hash[leading] ] >= remaining_zero:
        return True
    
    return False

def get_leading(n, hash):
    num_leading = 0
    for char in hash:
        if char != '0':
            break
        num_leading += 4
    
    return num_leading + zeroes[hash[num_leading//4 ].lower()]


def genPOW(n, hash):

    if check_leading(n, hash) == True:
        return "", hash, 0

    c = 33   #7-bit ascii character start

    pow = [chr(c)]
    length = 0
    iterations = 1
    message = "".join(pow) + hash
    hash2 = update_hash(str.encode(message))

    while not check_leading(n, hash2):
        c += 1
        if c >= 127:   #7-bit ascii character end
            c = 33
            
            back = True
            for i in range (length, -1, -1):
                if pow[i] == chr(126):
                    back = True
                    pow[i] = chr(33)
                else:
                    back = False
                    pow[i] = chr(ord(pow[i]) + 1)
                    break

            if back == True:
                pow.append(chr(33))
                length+=1
            
        else:
            pow[length] = chr(c)
        
        message = "".join(pow) + hash
        hash2 = update_hash(str.encode(message))
        iterations += 1


    return pow, hash2, iterations

def main():
    
    parser = argparse.ArgumentParser()

    parser.add_argument("difficulty", type=int)
    parser.add_argument("text")

    args = parser.parse_args()

    if not len(vars(args)) == 2:
        print("Error. Not enough arguments.")
        return

    if args.difficulty < 0:
        print("Error. Difficulty below 0.")
        return

    f = open(args.text, "rb")
    if not f:
        print("Error. File does not exist.")
        return

   

    hash1 = update_hash(f.read())

    start_time = time.time()

    pow, new_hash, iterations = genPOW(args.difficulty, hash1)

    end_time = time.time() - start_time

    
    leading = get_leading( args.difficulty, new_hash )


    print("File: {}".format(args.text))

    print("Initial-hash: {}".format(hash1))

    print("Proof-of-work: {}".format("".join(pow)))

    print("Hash: {}".format(new_hash))

    print("Leading-bits: {}".format(leading))

    print("Iterations: {}".format(iterations))
    
    print("Compute-time: {}".format(end_time))

    f.close()


if __name__ == "__main__":
    main()